import numpy as np

arr1 = np.array([10, 20, 30, 40])
arr2 = np.array([1, 2, 3, 4])

sum_arr = arr1 + arr2
mul_arr = arr1 * arr2
div_arr = arr1 / arr2

print("Sum of Arrays:", sum_arr)
print("Multiplication of Arrays:", mul_arr)
print("Division of Arrays:", div_arr)
