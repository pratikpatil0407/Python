import module

module.add(2,3)

module.sub(10,5)

module.mul(4,5)

module.div(20,5)