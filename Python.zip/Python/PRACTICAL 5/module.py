def add(a,b):
    sum=a+b
    print("Addition is",sum)

def sub(a,b):
    sub=a-b
    print("Subtraction is",sub)

def mul(a,b):
    mul=a*b
    print("Multiplication is",mul)

def div(a,b):
    div=a/b
    print("Division is",div)