n11 = int(n1.get())
    n22 = int(n2.get())
    res = n11 + n22
    l3.config(text=res)