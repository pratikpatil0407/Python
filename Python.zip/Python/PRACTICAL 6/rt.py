f1 = open("temp.txt","rt")
print(f1.read())