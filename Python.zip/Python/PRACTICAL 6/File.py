file = open("temp.txt",'x')

file1 = open("temp1.txt",'w')

file1.write("Hello World !!")

# file1.open("temp1.txt",'r')
# print(file1.read())