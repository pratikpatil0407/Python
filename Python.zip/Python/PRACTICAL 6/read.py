f = open("temp1.txt",'r')
print(f.read())