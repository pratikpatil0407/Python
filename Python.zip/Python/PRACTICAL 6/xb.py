f1 = open("miles.png",'xb')
