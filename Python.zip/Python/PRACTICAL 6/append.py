f1 = open("temp2.txt",'a')
f1.write("HELLO WORLD")

f2 = open("temp1.txt",'a')
f2.write("This is python")
