f1 = open('miles1.png','rb')
print(f1.read())