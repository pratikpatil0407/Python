f1 = open("miles2.bin","ab")
f1.write(b"Appending")
