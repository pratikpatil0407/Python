f1=open("temp.txt",'r+')
print(f1.read())