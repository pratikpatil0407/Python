x,y = map(int,input("Enter two numbers : ").split())

print("x equals y : ",(x == y))
print("x is greater y : ",(x > y))
print("x is less y : ",(x < y))
print("x not equals y : ",(x != y))
print("x is less than or equal to y : ",(x <= y))
print("x is greater than or equal to y : ",(x >= y))