x, y = map(int, input("Enter two numbers: ").split())


# Addition
print("The sum of given two numbera is : ",(x+y))

# Subtraction
print("The subtraction of given two numbera is : ",(x-y))

# Multiplication
print("The Multiplication of given two numbera is : ",(x*y))

# Division
print("The division of given two numbera is : ",(x/y))

# Modulus
print("The Modulus of given two numbera is : ",(x%y))

#  Floor division
print("The Floor division of given two numbera is : ",(x//y))

# Exponentiation
print("The  of given two numbera is : ",(x**y))