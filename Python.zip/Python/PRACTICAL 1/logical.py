x = 6

print(x<5 and x<10)

print(x<5 or x<10)

print(not(x<5))
