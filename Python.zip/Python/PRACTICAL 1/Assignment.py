x = 5
print("X =",x)
x+=4
print("X += 4 : ",x)
x-=4
print("X -= 4 : ",x)
x*=4
print("X *= 4 : ",x)
x/=4
print("X /= 4 : ",x)
x**=4
print("X **= 4 : ",x)
x//=4
print("X //= 4 : ",x)
x%=4
print("x %= 4 : ",x)



