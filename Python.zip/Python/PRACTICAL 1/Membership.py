data = ["Bike","Car","Plane"]

print("Plane is present in Data : ",("Plane" in data))

print("Plane is not present in Data : ",("Plane" not in data))

