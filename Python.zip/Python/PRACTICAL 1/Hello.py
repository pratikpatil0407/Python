a="Hello World!"
print(a)
print("The type of a is ",type(a))

b=4
print(b)
print("The type of b is ",type(b))

print(7*4)

print("My name is Pratik \nI am studying in T.Y")