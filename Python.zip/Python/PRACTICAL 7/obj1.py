class demo:
    # construcotr
    def __init__(self):
        print("This is default constructor")

ob1 = demo()
