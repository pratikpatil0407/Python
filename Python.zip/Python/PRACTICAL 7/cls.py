class student:
    Name = 'Digambar'
    Roll_No = 13
    
    def getMarks(self):
        marks = 20
        print(marks)

obj = student()
print(obj.Name)
print(obj.Roll_No)
obj.getMarks()