class demo:
    # construcotr        
    def __init__(self,num):
        print("This is paramaterized constructor : ",num)

obj = demo(1)
