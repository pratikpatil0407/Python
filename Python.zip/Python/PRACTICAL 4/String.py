a="Pratik\n"
print(a)

b='He said, "He wanted to eat apple"\n'
print(b)

c='''Lorem, ipsum dolor sit amet consectetur adipisicing elit. Recusandae in cum praesentium provident, 
distinctio repellat rem dolore accusantium necessitatibus beatae similique, inventore, earum quae quod 
iste ipsam. Aperiam, ex itaque?\n'''

print(c) # type: ignore